package Pages;

import org.openqa.selenium.WebDriver;


public class P02_LandingPage {

    private final WebDriver driver;

    public P02_LandingPage(WebDriver driver) {
        this.driver = driver;
    }


}


